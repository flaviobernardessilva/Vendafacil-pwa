COMO PUBLICAR NO NETLIFY
1. Entre em https://app.netlify.com/drop
2. Arraste a pasta crm_comercial_app ou o arquivo ZIP para a tela.
3. Aguarde publicar e copie o link gerado.

COMO PUBLICAR NO GITHUB PAGES
1. Abra o repositório do app.
2. Envie estes arquivos para a raiz do projeto: index.html, styles.css, app.js, data.js, manifest.webmanifest, sw.js e icon.svg.
3. Vá em Settings > Pages.
4. Selecione Deploy from branch, branch main, pasta /root.
5. Salve e aguarde o link.

O arquivo data.js contém os dados migrados da planilha Dashboard_Comercial_Final_Completo_2024_2026(1).xlsx.
