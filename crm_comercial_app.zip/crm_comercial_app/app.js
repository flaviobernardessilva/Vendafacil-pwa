const D = window.CRM_DATA;
const money = v => (Number(v)||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const pct = v => (Number(v)||0).toLocaleString('pt-BR',{style:'percent',minimumFractionDigits:1,maximumFractionDigits:1});
const byId = id => document.getElementById(id);
let deferredPrompt;
window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferredPrompt=e; byId('installBtn').hidden=false; });
byId('installBtn').onclick = async()=>{ if(deferredPrompt){ deferredPrompt.prompt(); deferredPrompt=null; byId('installBtn').hidden=true; }};
if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js');

const ranking = D.Ranking_Clientes || [];
const vendedores = D.Analise_Vendedores || [];
const resumo = D.Resumo_Mensal || [];
const abc = D.Curva_ABC || [];

function fillSelect(id, values){ const el=byId(id); [...new Set(values.filter(Boolean))].sort().forEach(v=>{ const o=document.createElement('option'); o.value=o.textContent=v; el.appendChild(o); }); }
fillSelect('seller', ranking.map(r=>r.Vendedor_Atual));
fillSelect('status', ranking.map(r=>r.Status_2026_vs_2025));
fillSelect('abc', abc.map(r=>r.Classe_ABC));

function enrichRows(){
  const abcMap = new Map(abc.map(r=>[String(r.ClienteChave), r.Classe_ABC]));
  return ranking.map(r=>({...r, Classe_ABC:abcMap.get(String(r.ClienteChave))||''}));
}
function filtered(){
  const q=byId('search').value.trim().toLowerCase(), seller=byId('seller').value, status=byId('status').value, classe=byId('abc').value;
  return enrichRows().filter(r => (!q || String(r.Cliente||'').toLowerCase().includes(q) || String(r.ClienteChave||'').includes(q)) && (!seller || r.Vendedor_Atual===seller) && (!status || r.Status_2026_vs_2025===status) && (!classe || r.Classe_ABC===classe));
}
function renderKpis(rows){
  const total2026 = rows.reduce((s,r)=>s+(+r.Total_2026||0),0);
  const total2025 = rows.reduce((s,r)=>s+(+r.Total_2025||0),0);
  const potencial = rows.reduce((s,r)=>s+(+r.Potencial_Recuperacao_R$||0),0);
  const perdidos = rows.filter(r=>String(r.Status_2026_vs_2025).includes('Perdido')).length;
  const items=[['Faturamento 2026',money(total2026),'base filtrada'],['Variação 26 x 25',pct((total2026-total2025)/(total2025||1)),'comparativo'],['Potencial recuperação',money(potencial),'queda + perdidos'],['Clientes perdidos',perdidos.toLocaleString('pt-BR'),'prioridade alta']];
  byId('kpis').innerHTML=items.map(i=>`<div class="card kpi"><span>${i[0]}</span><strong>${i[1]}</strong><span>${i[2]}</span></div>`).join('');
}
function drawMonthly(){
  const c=byId('monthlyChart'), ctx=c.getContext('2d'), w=c.width=c.clientWidth*devicePixelRatio, h=c.height=260*devicePixelRatio; ctx.scale(devicePixelRatio,devicePixelRatio); ctx.clearRect(0,0,w,h);
  const pad=38, W=c.clientWidth-pad*2, H=210, years=['2024','2025','2026'];
  const max=Math.max(...resumo.flatMap(r=>years.map(y=>+r[y]||0)));
  ctx.strokeStyle='#253047'; ctx.fillStyle='#94a3b8'; ctx.font='12px system-ui';
  for(let i=0;i<5;i++){let y=20+i*H/4; ctx.beginPath(); ctx.moveTo(pad,y); ctx.lineTo(pad+W,y); ctx.stroke();}
  years.forEach((yr, yi)=>{ctx.beginPath(); resumo.forEach((r,i)=>{let x=pad+i*(W/(resumo.length-1)); let y=20+H-((+r[yr]||0)/max)*H; i?ctx.lineTo(x,y):ctx.moveTo(x,y);}); ctx.lineWidth=3; ctx.strokeStyle=['#38bdf8','#f59e0b','#22c55e'][yi]; ctx.stroke(); ctx.fillStyle=ctx.strokeStyle; ctx.fillText(yr,pad+yi*55,250);});
  ctx.fillStyle='#94a3b8'; resumo.forEach((r,i)=>{if(i%2===0) ctx.fillText(String(r.Mes).slice(0,3),pad+i*(W/(resumo.length-1))-8,238);});
}
function renderFunnel(rows){
  const groups=['Queda','Perdido','Crescimento','Novo/Recuperado'].map(s=>({s, rows:rows.filter(r=>String(r.Status_2026_vs_2025).includes(s))}));
  const max=Math.max(...groups.map(g=>g.rows.length),1);
  byId('funnel').innerHTML=groups.map(g=>`<div class="step"><b><span>${g.s}</span><span>${g.rows.length}</span></b><div class="bar"><i style="width:${g.rows.length/max*100}%"></i></div><small>${money(g.rows.reduce((a,r)=>a+(+r.Potencial_Recuperacao_R$||0),0))}</small></div>`).join('');
}
function renderSellerRank(){
  const top=[...vendedores].sort((a,b)=>(+b.Total_2026||0)-(+a.Total_2026||0)).slice(0,8); const max=Math.max(...top.map(r=>+r.Total_2026||0),1);
  byId('sellerRank').innerHTML=top.map(r=>`<div class="rank-row"><div><b>${r.Vendedor}</b><div class="bar"><i style="width:${(+r.Total_2026||0)/max*100}%"></i></div></div><small>${money(r.Total_2026)}</small></div>`).join('');
}
function renderABC(rows){
  const totals={A:0,B:0,C:0}; rows.forEach(r=>{if(totals[r.Classe_ABC]!=null) totals[r.Classe_ABC]+=+r.Total_2026||0;}); const max=Math.max(...Object.values(totals),1);
  byId('abcChart').innerHTML=Object.entries(totals).map(([k,v])=>`<div class="abcItem"><div><b>Classe ${k}</b><span>${money(v)}</span></div><div class="bar"><i style="width:${v/max*100}%"></i></div></div>`).join('');
}
function tagClass(s){ if(!s) return ''; if(s.includes('Novo')) return 'Novo'; if(s.includes('Crescimento')) return 'Crescimento'; if(s.includes('Perdido')) return 'Perdido'; if(s.includes('Queda')) return 'Queda'; return 'Estável'; }
function renderTable(rows){
  byId('count').textContent=`${rows.length.toLocaleString('pt-BR')} clientes`;
  const head=['Vendedor','Código','Cliente','2024','2025','2026','Var. 26x25','Status','Potencial','ABC'];
  const body=rows.slice(0,500).map(r=>`<tr><td>${r.Vendedor_Atual||'-'}</td><td>${r.ClienteChave||''}</td><td>${r.Cliente||''}</td><td class="money">${money(r.Total_2024)}</td><td class="money">${money(r.Total_2025)}</td><td class="money">${money(r.Total_2026)}</td><td class="num">${pct(r.Var_26x25_%)}</td><td><span class="tag ${tagClass(r.Status_2026_vs_2025)}">${r.Status_2026_vs_2025||'-'}</span></td><td class="money">${money(r.Potencial_Recuperacao_R$)}</td><td>${r.Classe_ABC||'-'}</td></tr>`).join('');
  byId('clientsTable').innerHTML=`<thead><tr>${head.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${body}</tbody>`;
}
function renderAll(){ const rows=filtered(); renderKpis(rows); renderFunnel(rows); renderABC(rows); renderTable(rows); drawMonthly(); }
['search','seller','status','abc'].forEach(id=>byId(id).addEventListener('input',renderAll));
window.addEventListener('resize',drawMonthly);
byId('exportBtn').onclick=()=>{
  const rows=filtered(); const cols=['Vendedor_Atual','ClienteChave','Cliente','Total_2024','Total_2025','Total_2026','Var_26x25_%','Status_2026_vs_2025','Potencial_Recuperacao_R$','Classe_ABC'];
  const csv=[cols.join(';'),...rows.map(r=>cols.map(c=>`"${String(r[c]??'').replaceAll('"','""')}"`).join(';'))].join('\n');
  const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'})); a.download='clientes_filtrados_crm.csv'; a.click();
};
renderSellerRank(); renderAll();
